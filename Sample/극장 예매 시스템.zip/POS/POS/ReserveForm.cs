//�� ���� ��� ����..
//�� ������ ������ ReserveForm2 Ŭ������ �Ű�����..

using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.Odbc;

namespace POS
{
	/// <summary>
	/// Summary description for ReserveForm.
	/// </summary>
	public class ReserveForm : System.Windows.Forms.Form
	{
		private System.Data.Odbc.OdbcCommand odbcSelectCommand1;
		private System.Data.Odbc.OdbcConnection odbcConnection;
		private System.Data.Odbc.OdbcCommand odbcCommand;
		private System.Data.Odbc.OdbcDataAdapter odbcDataAdapter;
		
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;
		private System.Windows.Forms.ListBox movieList;
		
		//OdbcConnection nwindConn;// = new OdbcConnection("Driver={SQL Server};Server=localhost;" +
		//"Trusted_Connection=yes;Database=northwind");

		
		string source = "DRIVER={SQL Server};" + 
			"SERVER=localhost;" +
			"DATABASE=MICE;" +
			"UID=sa;" +
			"PASSWORD=;" +
			"OPTION=3";

		private OdbcConnection MyConnection=null;
		
		
		private OdbcDataAdapter adapter=null;
		private System.Windows.Forms.Label label1;
		private DataSet dataSet=null;

		

		ReserveForm2 rf2=null;
		
		public ReserveForm()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.odbcDataAdapter = new System.Data.Odbc.OdbcDataAdapter();
			this.odbcSelectCommand1 = new System.Data.Odbc.OdbcCommand();
			this.odbcConnection = new System.Data.Odbc.OdbcConnection();
			this.odbcCommand = new System.Data.Odbc.OdbcCommand();
			this.movieList = new System.Windows.Forms.ListBox();
			this.label1 = new System.Windows.Forms.Label();
			this.SuspendLayout();
			// 
			// odbcDataAdapter
			// 
			this.odbcDataAdapter.SelectCommand = this.odbcSelectCommand1;
			// 
			// odbcSelectCommand1
			// 
			this.odbcSelectCommand1.CommandText = @"SELECT Hall.pkHallNo, Hall.NumberOfSeat, Hall.SoundSystem, Hall.ProjectSystem, Hall.SizeOfScreen, Hall.HallInfo, Movie.pkMovieNo, Movie.MovieName, Movie.RunningTime, Movie.Grade, Movie.DirectorName, Movie.ActorName, Movie.Genre, Movie.MovieInfo, Movie.Poster, Payment.pkPaymentNo, Payment.pkPersonID, Payment.ReservationNo, Payment.PaymentState, Payment.PermitNo, Payment.Price, Payment.PaymentDate, Person.pkPersonID AS Expr1, Person.PersonPW, Person.PersonName, Person.PersonSCNo, Person.PersonPhone, Person.PersonZipCode, Person.PersonAddress, Person.PersonAuthority, Person.Point, Person.CoupleID, Person.IsCouple, Schedule.pkScheduleNo, Schedule.pkHallNo AS Expr2, Schedule.pkMovieNo AS Expr3, Schedule.RunningDate, Schedule.RoundNo, Schedule.RoundTime, Seat.pkSeatNo, Seat.pkHallNo AS Expr4, Seat.SeatNoInHall, Seat.SeatName, Seat.isUsableSeat, Ticket.pkTicketNo, Ticket.pkSeatName, Ticket.pkScheduleNo AS Expr5, Ticket.pkPaymentNo AS Expr6, Ticket.TicketState, Ticket.SalePrice, Ticket.SeatName AS Expr7 FROM Movie INNER JOIN Hall INNER JOIN Schedule ON Hall.pkHallNo = Schedule.pkHallNo ON Movie.pkMovieNo = Schedule.pkMovieNo INNER JOIN Seat ON Hall.pkHallNo = Seat.pkHallNo INNER JOIN Ticket ON Schedule.pkScheduleNo = Ticket.pkScheduleNo AND Seat.pkSeatNo = Ticket.pkSeatName INNER JOIN Person INNER JOIN Payment ON Person.pkPersonID = Payment.pkPersonID ON Ticket.pkPaymentNo = Payment.pkPaymentNo";
			this.odbcSelectCommand1.Connection = this.odbcConnection;
			// 
			// odbcConnection
			// 
			this.odbcConnection.ConnectionString = "Trusted_Connection=Yes;DSN=MICE;UID=sa;DATABASE=MICE;APP=Microsoft�� Visual Studio" +
				" .NET;WSID=KANGNB";
			// 
			// movieList
			// 
			this.movieList.ItemHeight = 12;
			this.movieList.Location = new System.Drawing.Point(48, 80);
			this.movieList.Name = "movieList";
			this.movieList.Size = new System.Drawing.Size(200, 88);
			this.movieList.TabIndex = 0;
			this.movieList.DoubleClick += new System.EventHandler(this.movieList_DoubleClick);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("GungsuhChe", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.label1.Location = new System.Drawing.Point(32, 24);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(184, 48);
			this.label1.TabIndex = 1;
			this.label1.Text = "���� ����";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// ReserveForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.ClientSize = new System.Drawing.Size(336, 282);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.movieList);
			this.Name = "ReserveForm";
			this.Text = "��ǥ����";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.ReserveForm_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void ReserveForm_Load(object sender, System.EventArgs e)
		{
			try
			{
				string QueryString = "SELECT pkMovieNo,MovieName FROM Movie";
                                                               
				// �����ͺ��̽� ����
				MyConnection = new OdbcConnection(source);    
				MyConnection.Open();

				adapter = new OdbcDataAdapter();
				dataSet = new DataSet();

				//string sqlStatement = QueryString;
				adapter.SelectCommand = new OdbcCommand( QueryString, MyConnection );
				adapter.Fill( dataSet );
            
				//ȭ�鿡 ���̱�
				DataTable dataTable = dataSet.Tables[0];
				//dataSet.Tables[0].Rows[

				string temp;
				
				foreach (DataRow row in dataTable.Rows)
				{
					/*
					string[] itemlist = new String[5] {row[0].ToString(), row[1].ToString(), row[2].ToString(), row[3].ToString(), row[4].ToString()};

					ListViewItem item = new ListViewItem(itemlist, 0);
                
					AlarmListView.Items.Add( item );    */

					temp = row[0].ToString() + "�� : "+row[1].ToString();
					movieList.Items.Add(temp);					
				}  				
				MyConnection.Close();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void movieList_DoubleClick(object sender, System.EventArgs e)
		{
			//int x=movieList.SelectedIndex+1;
			if( (rf2 == null) || (rf2.IsDisposed) )
			{				
				rf2 = new ReserveForm2(movieList.SelectedIndex+1, movieList.SelectedItem.ToString());
				rf2.MdiParent = this.MdiParent;			
				rf2.Show();
				//this.Close();
				
			}
			else
			{
				rf2.Show();
				//this.Close();
			}			
		}		
	}
}
