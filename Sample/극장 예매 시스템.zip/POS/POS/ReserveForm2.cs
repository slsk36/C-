using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Data.Odbc;

namespace POS
{
	/// <summary>
	/// Summary description for ReserveForm2.
	/// </summary>
	public class ReserveForm2 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private string source = "DRIVER={SQL Server};" + 
			"SERVER=58.120.67.2;" +   //58.120.67.2
			"DATABASE=MICE;" +
			"UID=sa;" +
			"PASSWORD=;" +
			"OPTION=3";
				
		//private DataSet dataSet=null;
		private System.Windows.Forms.PictureBox poster;
		private System.Windows.Forms.Label runningTime;
		private System.Windows.Forms.Label grade;
		private System.Windows.Forms.Label director;
		private System.Windows.Forms.Label actor;
		private System.Windows.Forms.Label genre;
		private System.Windows.Forms.RichTextBox content;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label hall;
		private System.Windows.Forms.ListBox timeList;
		private System.Windows.Forms.DateTimePicker dateTimePicker1;
		private int movieNo;	
		private int scheduleNo;
		private string movieName="";
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.ListBox movieList;
		private System.Data.Odbc.OdbcDataAdapter odbcDataAdapter;
		private System.Data.Odbc.OdbcCommand odbcSelectCommand1;
		private System.Data.Odbc.OdbcConnection odbcConnection;
		private System.Data.Odbc.OdbcCommand odbcCommand;

		ReserveForm3 rf3=null;

		public ReserveForm2()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
			movieNo=1;
			movieName="�̽��� ��ũ�� �׽�";
			movieInfo();
		}

		public ReserveForm2(int no, string str)
		{
			InitializeComponent();
			this.movieNo = no;
			this.movieName=str;

			//MessageBox.Show(MovieNo.ToString()+","+DateTime.Now.Date.ToShortDateString());
			//f.Close();
			movieInfo();
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.poster = new System.Windows.Forms.PictureBox();
			this.runningTime = new System.Windows.Forms.Label();
			this.grade = new System.Windows.Forms.Label();
			this.director = new System.Windows.Forms.Label();
			this.actor = new System.Windows.Forms.Label();
			this.genre = new System.Windows.Forms.Label();
			this.content = new System.Windows.Forms.RichTextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.hall = new System.Windows.Forms.Label();
			this.timeList = new System.Windows.Forms.ListBox();
			this.dateTimePicker1 = new System.Windows.Forms.DateTimePicker();
			this.label1 = new System.Windows.Forms.Label();
			this.movieList = new System.Windows.Forms.ListBox();
			this.odbcDataAdapter = new System.Data.Odbc.OdbcDataAdapter();
			this.odbcSelectCommand1 = new System.Data.Odbc.OdbcCommand();
			this.odbcConnection = new System.Data.Odbc.OdbcConnection();
			this.odbcCommand = new System.Data.Odbc.OdbcCommand();
			this.SuspendLayout();
			// 
			// poster
			// 
			this.poster.Location = new System.Drawing.Point(32, 40);
			this.poster.Name = "poster";
			this.poster.Size = new System.Drawing.Size(304, 408);
			this.poster.TabIndex = 9;
			this.poster.TabStop = false;
			// 
			// runningTime
			// 
			this.runningTime.Font = new System.Drawing.Font("DotumChe", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.runningTime.Location = new System.Drawing.Point(344, 40);
			this.runningTime.Name = "runningTime";
			this.runningTime.Size = new System.Drawing.Size(248, 24);
			this.runningTime.TabIndex = 10;
			this.runningTime.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// grade
			// 
			this.grade.Font = new System.Drawing.Font("DotumChe", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.grade.Location = new System.Drawing.Point(344, 72);
			this.grade.Name = "grade";
			this.grade.Size = new System.Drawing.Size(248, 24);
			this.grade.TabIndex = 10;
			this.grade.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// director
			// 
			this.director.Font = new System.Drawing.Font("DotumChe", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.director.Location = new System.Drawing.Point(344, 104);
			this.director.Name = "director";
			this.director.Size = new System.Drawing.Size(248, 24);
			this.director.TabIndex = 10;
			this.director.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// actor
			// 
			this.actor.Font = new System.Drawing.Font("DotumChe", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.actor.Location = new System.Drawing.Point(344, 136);
			this.actor.Name = "actor";
			this.actor.Size = new System.Drawing.Size(312, 32);
			this.actor.TabIndex = 10;
			this.actor.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// genre
			// 
			this.genre.Font = new System.Drawing.Font("DotumChe", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.genre.Location = new System.Drawing.Point(344, 176);
			this.genre.Name = "genre";
			this.genre.Size = new System.Drawing.Size(248, 24);
			this.genre.TabIndex = 10;
			this.genre.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// content
			// 
			this.content.BackColor = System.Drawing.SystemColors.Control;
			this.content.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.content.Location = new System.Drawing.Point(344, 240);
			this.content.Name = "content";
			this.content.Size = new System.Drawing.Size(312, 272);
			this.content.TabIndex = 11;
			this.content.Text = "";
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("DotumChe", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.label7.Location = new System.Drawing.Point(344, 208);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(104, 24);
			this.label7.TabIndex = 12;
			this.label7.Text = "�� ȭ �� �� :";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// hall
			// 
			this.hall.Font = new System.Drawing.Font("Gungsuh", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.hall.Location = new System.Drawing.Point(712, 200);
			this.hall.Name = "hall";
			this.hall.Size = new System.Drawing.Size(200, 32);
			this.hall.TabIndex = 13;
			this.hall.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// timeList
			// 
			this.timeList.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.timeList.Font = new System.Drawing.Font("Gulim", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.timeList.ItemHeight = 15;
			this.timeList.Location = new System.Drawing.Point(696, 256);
			this.timeList.Name = "timeList";
			this.timeList.Size = new System.Drawing.Size(232, 210);
			this.timeList.TabIndex = 14;
			this.timeList.DoubleClick += new System.EventHandler(this.timeList_DoubleClick);
			// 
			// dateTimePicker1
			// 
			this.dateTimePicker1.Location = new System.Drawing.Point(720, 64);
			this.dateTimePicker1.Name = "dateTimePicker1";
			this.dateTimePicker1.Size = new System.Drawing.Size(168, 21);
			this.dateTimePicker1.TabIndex = 15;
			this.dateTimePicker1.ValueChanged += new System.EventHandler(this.dateTimePicker1_ValueChanged);
			// 
			// label1
			// 
			this.label1.Font = new System.Drawing.Font("GungsuhChe", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.label1.Location = new System.Drawing.Point(32, 456);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(184, 48);
			this.label1.TabIndex = 17;
			this.label1.Text = "���� ����";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// movieList
			// 
			this.movieList.ItemHeight = 12;
			this.movieList.Location = new System.Drawing.Point(48, 512);
			this.movieList.Name = "movieList";
			this.movieList.Size = new System.Drawing.Size(200, 88);
			this.movieList.TabIndex = 16;
			this.movieList.DoubleClick += new System.EventHandler(this.movieList_DoubleClick);
			// 
			// odbcDataAdapter
			// 
			this.odbcDataAdapter.SelectCommand = this.odbcSelectCommand1;
			this.odbcDataAdapter.TableMappings.AddRange(new System.Data.Common.DataTableMapping[] {
																									  new System.Data.Common.DataTableMapping("Table", "Movie", new System.Data.Common.DataColumnMapping[] {
																																																			   new System.Data.Common.DataColumnMapping("pkHallNo", "pkHallNo"),
																																																			   new System.Data.Common.DataColumnMapping("NumberOfSeat", "NumberOfSeat"),
																																																			   new System.Data.Common.DataColumnMapping("SoundSystem", "SoundSystem"),
																																																			   new System.Data.Common.DataColumnMapping("ProjectSystem", "ProjectSystem"),
																																																			   new System.Data.Common.DataColumnMapping("SizeOfScreen", "SizeOfScreen"),
																																																			   new System.Data.Common.DataColumnMapping("HallInfo", "HallInfo"),
																																																			   new System.Data.Common.DataColumnMapping("pkMovieNo", "pkMovieNo"),
																																																			   new System.Data.Common.DataColumnMapping("MovieName", "MovieName"),
																																																			   new System.Data.Common.DataColumnMapping("RunningTime", "RunningTime"),
																																																			   new System.Data.Common.DataColumnMapping("Grade", "Grade"),
																																																			   new System.Data.Common.DataColumnMapping("DirectorName", "DirectorName"),
																																																			   new System.Data.Common.DataColumnMapping("ActorName", "ActorName"),
																																																			   new System.Data.Common.DataColumnMapping("Genre", "Genre"),
																																																			   new System.Data.Common.DataColumnMapping("MovieInfo", "MovieInfo"),
																																																			   new System.Data.Common.DataColumnMapping("Poster", "Poster"),
																																																			   new System.Data.Common.DataColumnMapping("pkPaymentNo", "pkPaymentNo"),
																																																			   new System.Data.Common.DataColumnMapping("pkPersonID", "pkPersonID"),
																																																			   new System.Data.Common.DataColumnMapping("ReservationNo", "ReservationNo"),
																																																			   new System.Data.Common.DataColumnMapping("PaymentState", "PaymentState"),
																																																			   new System.Data.Common.DataColumnMapping("PermitNo", "PermitNo"),
																																																			   new System.Data.Common.DataColumnMapping("Price", "Price"),
																																																			   new System.Data.Common.DataColumnMapping("PaymentDate", "PaymentDate"),
																																																			   new System.Data.Common.DataColumnMapping("Expr1", "Expr1"),
																																																			   new System.Data.Common.DataColumnMapping("PersonPW", "PersonPW"),
																																																			   new System.Data.Common.DataColumnMapping("PersonName", "PersonName"),
																																																			   new System.Data.Common.DataColumnMapping("PersonSCNo", "PersonSCNo"),
																																																			   new System.Data.Common.DataColumnMapping("PersonPhone", "PersonPhone"),
																																																			   new System.Data.Common.DataColumnMapping("PersonEmail", "PersonEmail"),
																																																			   new System.Data.Common.DataColumnMapping("PersonZipCode", "PersonZipCode"),
																																																			   new System.Data.Common.DataColumnMapping("PersonAddress", "PersonAddress"),
																																																			   new System.Data.Common.DataColumnMapping("PersonAuthority", "PersonAuthority"),
																																																			   new System.Data.Common.DataColumnMapping("Point", "Point"),
																																																			   new System.Data.Common.DataColumnMapping("CoupleID", "CoupleID"),
																																																			   new System.Data.Common.DataColumnMapping("IsCouple", "IsCouple"),
																																																			   new System.Data.Common.DataColumnMapping("FavoriteAreaA", "FavoriteAreaA"),
																																																			   new System.Data.Common.DataColumnMapping("FavoriteAreaB", "FavoriteAreaB"),
																																																			   new System.Data.Common.DataColumnMapping("FavoriteAreaC", "FavoriteAreaC"),
																																																			   new System.Data.Common.DataColumnMapping("FavoriteAreaD", "FavoriteAreaD"),
																																																			   new System.Data.Common.DataColumnMapping("FavoriteAreaE", "FavoriteAreaE"),
																																																			   new System.Data.Common.DataColumnMapping("FavoriteAreaF", "FavoriteAreaF"),
																																																			   new System.Data.Common.DataColumnMapping("FavoriteAreaG", "FavoriteAreaG"),
																																																			   new System.Data.Common.DataColumnMapping("FavoriteAreaH", "FavoriteAreaH"),
																																																			   new System.Data.Common.DataColumnMapping("FavoriteAreaI", "FavoriteAreaI"),
																																																			   new System.Data.Common.DataColumnMapping("pkScheduleNo", "pkScheduleNo"),
																																																			   new System.Data.Common.DataColumnMapping("Expr2", "Expr2"),
																																																			   new System.Data.Common.DataColumnMapping("Expr3", "Expr3"),
																																																			   new System.Data.Common.DataColumnMapping("RunningDate", "RunningDate"),
																																																			   new System.Data.Common.DataColumnMapping("RoundNo", "RoundNo"),
																																																			   new System.Data.Common.DataColumnMapping("RoundTime", "RoundTime"),
																																																			   new System.Data.Common.DataColumnMapping("pkSeatNo", "pkSeatNo"),
																																																			   new System.Data.Common.DataColumnMapping("Expr4", "Expr4"),
																																																			   new System.Data.Common.DataColumnMapping("SeatNoInHall", "SeatNoInHall"),
																																																			   new System.Data.Common.DataColumnMapping("SeatName", "SeatName"),
																																																			   new System.Data.Common.DataColumnMapping("isUsableSeat", "isUsableSeat"),
																																																			   new System.Data.Common.DataColumnMapping("pkTicketNo", "pkTicketNo"),
																																																			   new System.Data.Common.DataColumnMapping("pkSeatName", "pkSeatName"),
																																																			   new System.Data.Common.DataColumnMapping("Expr5", "Expr5"),
																																																			   new System.Data.Common.DataColumnMapping("Expr6", "Expr6"),
																																																			   new System.Data.Common.DataColumnMapping("TicketState", "TicketState"),
																																																			   new System.Data.Common.DataColumnMapping("SalePrice", "SalePrice"),
																																																			   new System.Data.Common.DataColumnMapping("Expr7", "Expr7")})});
			// 
			// odbcSelectCommand1
			// 
			this.odbcSelectCommand1.CommandText = "SELECT Hall.pkHallNo, Hall.NumberOfSeat, Hall.SoundSystem, Hall.ProjectSystem, Ha" +
				"ll.SizeOfScreen, Hall.HallInfo, Movie.pkMovieNo, Movie.MovieName, Movie.RunningT" +
				"ime, Movie.Grade, Movie.DirectorName, Movie.ActorName, Movie.Genre, Movie.MovieI" +
				"nfo, Movie.Poster, Payment.pkPaymentNo, Payment.pkPersonID, Payment.ReservationN" +
				"o, Payment.PaymentState, Payment.PermitNo, Payment.Price, Payment.PaymentDate, P" +
				"erson.pkPersonID AS Expr1, Person.PersonPW, Person.PersonName, Person.PersonSCNo" +
				", Person.PersonPhone, Person.PersonEmail, Person.PersonZipCode, Person.PersonAdd" +
				"ress, Person.PersonAuthority, Person.Point, Person.CoupleID, Person.IsCouple, Pe" +
				"rson.FavoriteAreaA, Person.FavoriteAreaB, Person.FavoriteAreaC, Person.FavoriteA" +
				"reaD, Person.FavoriteAreaE, Person.FavoriteAreaF, Person.FavoriteAreaG, Person.F" +
				"avoriteAreaH, Person.FavoriteAreaI, Schedule.pkScheduleNo, Schedule.pkHallNo AS " +
				"Expr2, Schedule.pkMovieNo AS Expr3, Schedule.RunningDate, Schedule.RoundNo, Sche" +
				"dule.RoundTime, Seat.pkSeatNo, Seat.pkHallNo AS Expr4, Seat.SeatNoInHall, Seat.S" +
				"eatName, Seat.isUsableSeat, Ticket.pkTicketNo, Ticket.pkSeatName, Ticket.pkSched" +
				"uleNo AS Expr5, Ticket.pkPaymentNo AS Expr6, Ticket.TicketState, Ticket.SalePric" +
				"e, Ticket.SeatName AS Expr7 FROM Movie INNER JOIN Hall INNER JOIN Schedule ON Ha" +
				"ll.pkHallNo = Schedule.pkHallNo ON Movie.pkMovieNo = Schedule.pkMovieNo INNER JO" +
				"IN Seat ON Hall.pkHallNo = Seat.pkHallNo INNER JOIN Ticket ON Schedule.pkSchedul" +
				"eNo = Ticket.pkScheduleNo AND Seat.pkSeatNo = Ticket.pkSeatName INNER JOIN Perso" +
				"n INNER JOIN Payment ON Person.pkPersonID = Payment.pkPersonID ON Ticket.pkPayme" +
				"ntNo = Payment.pkPaymentNo";
			this.odbcSelectCommand1.Connection = this.odbcConnection;
			// 
			// odbcConnection
			// 
			this.odbcConnection.ConnectionString = "DSN=MICE;UID=sa;DATABASE=MICE;APP=Microsoft�� Visual Studio .NET;WSID=KANGNB";
			// 
			// ReserveForm2
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.AutoScroll = true;
			this.BackColor = System.Drawing.SystemColors.Control;
			this.ClientSize = new System.Drawing.Size(920, 652);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.movieList);
			this.Controls.Add(this.dateTimePicker1);
			this.Controls.Add(this.timeList);
			this.Controls.Add(this.hall);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.content);
			this.Controls.Add(this.runningTime);
			this.Controls.Add(this.poster);
			this.Controls.Add(this.grade);
			this.Controls.Add(this.director);
			this.Controls.Add(this.actor);
			this.Controls.Add(this.genre);
			this.Name = "ReserveForm2";
			this.Text = "��ȭ �󿵽ð�";
			this.TransparencyKey = System.Drawing.Color.Transparent;
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.ReserveForm2_Load);
			//this.Closed += new System.EventHandler(this.ReserveForm2_Closed);
			this.ResumeLayout(false);

		}
		#endregion

		public void movieInfo()
		{
			timeList.Items.Clear();			
			
			try
			{
				string QueryString = "SELECT * FROM Movie WHERE pkMovieNo="+movieNo.ToString();
                DataRow row1;       
                DataTable dataTable1, dataTable2; 
                DataSet dataSet1, dataSet2;  
     
				// �����ͺ��̽� ����
				odbcConnection = new OdbcConnection(source);    
				odbcConnection.Open();

				odbcDataAdapter = new OdbcDataAdapter();
				dataSet1 = new DataSet();

				//string sqlStatement = QueryString;
				odbcDataAdapter.SelectCommand = new OdbcCommand( QueryString, odbcConnection );
				odbcDataAdapter.Fill( dataSet1 );
            
				//ȭ�鿡 ���̱�
				dataTable1 = dataSet1.Tables[0];
				//dataSet.Tables[0].Rows[

				//string temp;
				
				//
				row1 = dataTable1.Rows[0];	
				
				//������ ���
				poster.Image = Image.FromFile(@"C:\\Inetpub\\mice\poster\\"+row1[8].ToString());

				runningTime.Text = "�� �� �� �� : "+row1[2].ToString() + " ��";//�󿵽ð�
				grade.Text       = "��       �� : "+row1[3].ToString() + " �� �̻� ������";
				director.Text    = "��       �� : "+row1[4].ToString(); 
				actor.Text       = "�� �� �� �� : "+row1[5].ToString();
				genre.Text       = "��       �� : "+row1[6].ToString();
				content.Text     = row1[7].ToString().Replace("<br>","");
				//��ȭ ����
			


				//foreach (DataRow row in dataTable.Rows)
				//{
					/*
					string[] itemlist = new String[5] {row[0].ToString(), row[1].ToString(), row[2].ToString(), row[3].ToString(), row[4].ToString()};

					ListViewItem item = new ListViewItem(itemlist, 0);
                
					AlarmListView.Items.Add( item );    */

					//temp = row[0].ToString() + "�� : "+row[1].ToString();
					//movieList.Items.Add(temp);
					
				//}
  				
				QueryString = "SELECT * FROM Schedule WHERE pkMovieNo=";
				QueryString+=  movieNo.ToString() + " and RunningDate='"+DateTime.Now.ToShortDateString()+"'";
				dataSet2 = new DataSet();
				odbcDataAdapter.SelectCommand = new OdbcCommand( QueryString, odbcConnection );
				odbcDataAdapter.Fill( dataSet2 );

				dataTable2 = dataSet2.Tables[0];

				
				hall.Text = movieNo.ToString() + "��";
				DataRow row = dataTable2.Rows[0];
				scheduleNo = Int32.Parse(row[0].ToString());

				foreach(DataRow dr in dataTable2.Rows)
				{				
					timeList.Items.Add(dr[4].ToString()+"ȸ  "+dr[5].ToString());
				}
				
				odbcConnection.Close();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
			//MessageBox.Show("����");
		}	

		private void dateTimePicker1_ValueChanged(object sender, System.EventArgs e)
		{
			//MessageBox.Show(dateTimePicker1.Value.ToShortDateString());
			try
			{				
				//DataRow row;       
				DataTable dataTable; 
				DataSet dataSet;  
     
				// �����ͺ��̽� ����
				odbcConnection = new OdbcConnection(source);    
				odbcConnection.Open();

				odbcDataAdapter = new OdbcDataAdapter();
				dataSet = new DataSet();


				string QueryString = "SELECT * FROM Schedule WHERE pkMovieNo=";
				QueryString+=  movieNo.ToString() + " and RunningDate='"+dateTimePicker1.Value.ToShortDateString()+"'";
				dataSet= new DataSet();
				odbcDataAdapter.SelectCommand = new OdbcCommand( QueryString, odbcConnection );
				odbcDataAdapter.Fill( dataSet );

				dataTable = dataSet.Tables[0];
				
				
				
				hall.Text = movieNo.ToString() + "��";
				timeList.Items.Clear();//���� �󿵽ð� ����

				//����Ÿ�� ������ ��, ������ ���ڿ� �� ������ ������
				if(dataTable.Rows.Count==0)
				{
					timeList.Items.Add("�� ������ �����ϴ�.");
				}
				else//�� ������ ������..
				{				
					DataRow row = dataTable.Rows[0];
					//������ ��ȣ�� �����Ѵ�.
					scheduleNo = Int32.Parse(row[0].ToString());
					foreach(DataRow dr in dataTable.Rows)
					{				
						//MessageBox.Show("�ð��� �ٲ�");
						timeList.Items.Add(dr[4].ToString()+"ȸ  "+dr[5].ToString());					
					}
				}
				
				odbcConnection.Close();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void timeList_DoubleClick(object sender, System.EventArgs e)
		{
			if(timeList.Items.Count==1)
			{
				return;
			}
			else
			{
				//MessageBox.Show(timeList.SelectedIndex.ToString());

				if( (rf3 == null) || (rf3.IsDisposed) )
				{				
					//������ ��ȣ�� ������ �Ѱ���..
					rf3 = new ReserveForm3(scheduleNo+timeList.SelectedIndex, (movieName+" "+timeList.SelectedItem.ToString()), movieNo );
					rf3.MdiParent = this.MdiParent;			
					rf3.Show();
					//this.Close();
				
				}
				else
				{
					rf3.Show();
					//this.Close();
				}			
			}
		}

		private void ReserveForm2_Load(object sender, System.EventArgs e)
		{
			try
			{
				//DataTable dataTable; 
				DataSet dataSet;  
				string QueryString = "SELECT pkMovieNo,MovieName FROM Movie";
                                                               
				// �����ͺ��̽� ����
				odbcConnection = new OdbcConnection(source);    
				odbcConnection.Open();

				odbcDataAdapter = new OdbcDataAdapter();
				dataSet = new DataSet();

				//string sqlStatement = QueryString;
				odbcDataAdapter.SelectCommand = new OdbcCommand( QueryString, odbcConnection );
				odbcDataAdapter.Fill( dataSet );
            
				//ȭ�鿡 ���̱�
				DataTable dataTable = dataSet.Tables[0];
				//dataSet.Tables[0].Rows[

				string temp;
				
				foreach (DataRow row in dataTable.Rows)
				{
					/*
					string[] itemlist = new String[5] {row[0].ToString(), row[1].ToString(), row[2].ToString(), row[3].ToString(), row[4].ToString()};

					ListViewItem item = new ListViewItem(itemlist, 0);
                
					AlarmListView.Items.Add( item );    */

					temp = row[0].ToString() + "�� : "+row[1].ToString();
					movieList.Items.Add(temp);					
				}  				
				odbcConnection.Close();
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}

		private void movieList_DoubleClick(object sender, System.EventArgs e)
		{
			movieNo = movieList.SelectedIndex+1;
			movieName = movieList.SelectedItem.ToString();			
			movieInfo();
		}

		
		
	}	
}
