using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.IO;
using System.Data;
using System.Data.Odbc;

namespace POS
{
	/// <summary>
	/// Summary description for ReserveForm3.
	/// </summary>
	public class ReserveForm3 : System.Windows.Forms.Form
	{
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		private System.Windows.Forms.Label [,] seat;
		private System.Windows.Forms.Label [] seatRow; //�¼� ���ο� �ε���
		private System.Windows.Forms.Label [] seatCol;

		private int scheduleNo;
		private System.Windows.Forms.Label scheduleInfo;
		private string schedule;
		private int movieNo;
		private int row, col;  //���ο�, ���ο� ������ �ε��� ����
		private string hall="C:\\Inetpub\\mice\\seat\\hallNo";
		private int margin=30, size=20;//���� ���̺����� ���ݰ� ���̺� ������
		private int startX=80, startY=80;
		private ArrayList seatName = new ArrayList();
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label4;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Label label5;
		private System.Windows.Forms.Button button1;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.Label label8;
		private System.Windows.Forms.TextBox textId;
		private System.Windows.Forms.Label label6;
		private int price;  //��ǥ ����
		private int point;  //���ϸ���
		private ArrayList seatNo = new ArrayList();
		private ArrayList seatReve = new ArrayList();
		private System.Data.Odbc.OdbcDataAdapter odbcDataAdapter;
		private System.Data.Odbc.OdbcCommand odbcSelectCommand1;
		private System.Data.Odbc.OdbcConnection odbcConnection;
		private System.Data.Odbc.OdbcCommand odbcCommand;
		//private string seatR="";

		//ODBC���� �ҽ�
		private string source = "DRIVER={SQL Server};" + 
			"SERVER=58.120.67.2;" +  //58.120.67.2
			"DATABASE=MICE;" +
			"UID=sa;" +
			"PASSWORD=;" +
			"OPTION=3";

		public ReserveForm3()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}
		public ReserveForm3(int scheduleNo, string schedule, int movieNo)
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//

			this.scheduleNo = scheduleNo;
			this.schedule = schedule;
			this.movieNo = movieNo;	
			this.hall += movieNo.ToString();
			//MessageBox.Show(scheduleNo.ToString());

			//MessageBox.Show(hall);
		}


		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.scheduleInfo = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.label4 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.label3 = new System.Windows.Forms.Label();
			this.label5 = new System.Windows.Forms.Label();
			this.label6 = new System.Windows.Forms.Label();
			this.button1 = new System.Windows.Forms.Button();
			this.textId = new System.Windows.Forms.TextBox();
			this.label7 = new System.Windows.Forms.Label();
			this.label8 = new System.Windows.Forms.Label();
			this.odbcDataAdapter = new System.Data.Odbc.OdbcDataAdapter();
			this.odbcSelectCommand1 = new System.Data.Odbc.OdbcCommand();
			this.odbcConnection = new System.Data.Odbc.OdbcConnection();
			this.odbcCommand = new System.Data.Odbc.OdbcCommand();
			this.SuspendLayout();
			// 
			// scheduleInfo
			// 
			this.scheduleInfo.Font = new System.Drawing.Font("GulimChe", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.scheduleInfo.ForeColor = System.Drawing.SystemColors.ActiveCaption;
			this.scheduleInfo.Location = new System.Drawing.Point(32, 12);
			this.scheduleInfo.Name = "scheduleInfo";
			this.scheduleInfo.Size = new System.Drawing.Size(520, 24);
			this.scheduleInfo.TabIndex = 3;
			this.scheduleInfo.Text = "label5";
			this.scheduleInfo.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			this.scheduleInfo.MouseUp += new System.Windows.Forms.MouseEventHandler(this.scheduleInfo_MouseUp);
			// 
			// label1
			// 
			this.label1.BackColor = System.Drawing.SystemColors.HighlightText;
			this.label1.Location = new System.Drawing.Point(592, 16);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(20, 20);
			this.label1.TabIndex = 4;
			// 
			// label4
			// 
			this.label4.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.label4.Location = new System.Drawing.Point(616, 16);
			this.label4.Name = "label4";
			this.label4.Size = new System.Drawing.Size(48, 24);
			this.label4.TabIndex = 5;
			this.label4.Text = "�� �¼�";
			this.label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label2
			// 
			this.label2.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.label2.Location = new System.Drawing.Point(800, 16);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(88, 24);
			this.label2.TabIndex = 7;
			this.label2.Text = "���� �Ϸ� �¼�";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// label3
			// 
			this.label3.BackColor = System.Drawing.SystemColors.HotTrack;
			this.label3.Location = new System.Drawing.Point(776, 16);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(20, 20);
			this.label3.TabIndex = 6;
			// 
			// label5
			// 
			this.label5.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
			this.label5.Location = new System.Drawing.Point(672, 16);
			this.label5.Name = "label5";
			this.label5.Size = new System.Drawing.Size(20, 20);
			this.label5.TabIndex = 6;
			// 
			// label6
			// 
			this.label6.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.label6.Location = new System.Drawing.Point(696, 16);
			this.label6.Name = "label6";
			this.label6.Size = new System.Drawing.Size(64, 24);
			this.label6.TabIndex = 7;
			this.label6.Text = "���� �¼�";
			this.label6.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
			// 
			// button1
			// 
			this.button1.Location = new System.Drawing.Point(840, 200);
			this.button1.Name = "button1";
			this.button1.Size = new System.Drawing.Size(104, 48);
			this.button1.TabIndex = 8;
			this.button1.Text = "��    ��";
			this.button1.Click += new System.EventHandler(this.button1_Click);
			// 
			// textId
			// 
			this.textId.Location = new System.Drawing.Point(816, 160);
			this.textId.Name = "textId";
			this.textId.Size = new System.Drawing.Size(144, 21);
			this.textId.TabIndex = 9;
			this.textId.Text = "";
			// 
			// label7
			// 
			this.label7.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.label7.Location = new System.Drawing.Point(832, 128);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(104, 24);
			this.label7.TabIndex = 10;
			this.label7.Text = "���ϸ��� ����";
			this.label7.TextAlign = System.Drawing.ContentAlignment.BottomLeft;
			// 
			// label8
			// 
			this.label8.Font = new System.Drawing.Font("Gulim", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
			this.label8.Location = new System.Drawing.Point(768, 160);
			this.label8.Name = "label8";
			this.label8.Size = new System.Drawing.Size(48, 24);
			this.label8.TabIndex = 11;
			this.label8.Text = "ID  :  ";
			this.label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
			// 
			// odbcDataAdapter
			// 
			this.odbcDataAdapter.SelectCommand = this.odbcSelectCommand1;
			// 
			// odbcSelectCommand1
			// 
			this.odbcSelectCommand1.CommandText = "SELECT Hall.pkHallNo, Hall.NumberOfSeat, Hall.SoundSystem, Hall.ProjectSystem, Ha" +
				"ll.SizeOfScreen, Hall.HallInfo, Movie.pkMovieNo, Movie.MovieName, Movie.RunningT" +
				"ime, Movie.Grade, Movie.DirectorName, Movie.ActorName, Movie.Genre, Movie.MovieI" +
				"nfo, Movie.Poster, Payment.pkPaymentNo, Payment.pkPersonID, Payment.ReservationN" +
				"o, Payment.PaymentState, Payment.PermitNo, Payment.Price, Payment.PaymentDate, P" +
				"erson.pkPersonID AS Expr1, Person.PersonPW, Person.PersonName, Person.PersonSCNo" +
				", Person.PersonPhone, Person.PersonEmail, Person.PersonZipCode, Person.PersonAdd" +
				"ress, Person.PersonAuthority, Person.Point, Person.CoupleID, Person.IsCouple, Pe" +
				"rson.FavoriteAreaA, Person.FavoriteAreaB, Person.FavoriteAreaC, Person.FavoriteA" +
				"reaD, Person.FavoriteAreaE, Person.FavoriteAreaF, Person.FavoriteAreaG, Person.F" +
				"avoriteAreaH, Person.FavoriteAreaI, Schedule.pkScheduleNo, Schedule.pkHallNo AS " +
				"Expr2, Schedule.pkMovieNo AS Expr3, Schedule.RunningDate, Schedule.RoundNo, Sche" +
				"dule.RoundTime, Seat.pkSeatNo, Seat.pkHallNo AS Expr4, Seat.SeatNoInHall, Seat.S" +
				"eatName, Seat.isUsableSeat, Ticket.pkTicketNo, Ticket.pkSeatName, Ticket.pkSched" +
				"uleNo AS Expr5, Ticket.pkPaymentNo AS Expr6, Ticket.TicketState, Ticket.SalePric" +
				"e, Ticket.SeatName AS Expr7 FROM Movie INNER JOIN Hall INNER JOIN Schedule ON Ha" +
				"ll.pkHallNo = Schedule.pkHallNo ON Movie.pkMovieNo = Schedule.pkMovieNo INNER JO" +
				"IN Seat ON Hall.pkHallNo = Seat.pkHallNo INNER JOIN Ticket ON Schedule.pkSchedul" +
				"eNo = Ticket.pkScheduleNo AND Seat.pkSeatNo = Ticket.pkSeatName INNER JOIN Perso" +
				"n INNER JOIN Payment ON Person.pkPersonID = Payment.pkPersonID ON Ticket.pkPayme" +
				"ntNo = Payment.pkPaymentNo";
			this.odbcSelectCommand1.Connection = this.odbcConnection;
			// 
			// odbcConnection
			// 
			this.odbcConnection.ConnectionString = "Trusted_Connection=Yes;DSN=MICE;UID=sa;DATABASE=MICE;APP=Microsoft�� Visual Studio" +
				" .NET;WSID=KANGNB";
			// 
			// ReserveForm3
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(6, 14);
			this.ClientSize = new System.Drawing.Size(1028, 382);
			this.Controls.Add(this.label8);
			this.Controls.Add(this.label7);
			this.Controls.Add(this.textId);
			this.Controls.Add(this.button1);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label4);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.scheduleInfo);
			this.Controls.Add(this.label5);
			this.Controls.Add(this.label6);
			this.Name = "ReserveForm3";
			this.Text = "�� �� �� ��";
			this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
			this.Load += new System.EventHandler(this.ReserveForm3_Load);
			this.ResumeLayout(false);

		}
		#endregion

		private void ReserveForm3_Load(object sender, System.EventArgs e)
		{
			string str="";
			//string [] temp = seatR.Split(';');
			loadData();//�� �ε�� ����� �¼� �ҷ�����..
			//MessageBox.Show(scheduleNo.ToString());
			//������ ����..
			loadLabel();
			
			
			for(int i=0 ; i<this.row ; i++)
			{
				for(int j=0 ; j<this.col ; j++)
				{
					for(int k=0 ; k<seatReve.Count ; k++)
					{
						int check = -1;
						check = this.seat[i,j].Name.CompareTo( str );
						str = seatReve[k].ToString();
						if( check == 0 )
						{
							this.seat[i,j].BackColor = System.Drawing.SystemColors.HotTrack;
						}
					}		
				}
			}			
		}

		private void seat_Click(object sender, System.EventArgs e)
		{
			Label l = (Label)sender;
			//MessageBox.Show(l.Name);
			
			
			if(l.BackColor == System.Drawing.SystemColors.HighlightText) 
			{
				l.BackColor = System.Drawing.SystemColors.InactiveCaptionText;
				seatName.Add(l.Name);
			}
			else if(l.BackColor == System.Drawing.SystemColors.InactiveCaptionText) 
			{
				l.BackColor = System.Drawing.SystemColors.HighlightText;
				seatName.Remove(l.Name);
			}
			else 
			{
				string str = l.Name+"�� �Ǹ� ����Ͻðڽ��ϱ�?";
				if(MessageBox.Show(str, "�� �� �� ��",
					MessageBoxButtons.OKCancel, MessageBoxIcon.Question)==DialogResult.OK)
				{
					try
					{
						DataRow row;      
						DataTable dataTable; 
						DataSet dataSet; 
						string QueryString="";
     
						// �����ͺ��̽� ����
						odbcConnection = new OdbcConnection(source);    
						odbcConnection.Open();

						odbcDataAdapter = new OdbcDataAdapter();
						dataSet = new DataSet();						
						
						QueryString = "SELECT pkSeatNo FROM Seat WHERE SeatName='"+l.Name+"' and pkHallNo="+movieNo.ToString();
						
						odbcDataAdapter.SelectCommand = new OdbcCommand( QueryString, odbcConnection );
						odbcDataAdapter.Fill( dataSet );

						dataTable = dataSet.Tables[0];
						row = dataTable.Rows[0];

						QueryString = "DELETE FROM Ticket WHERE pkSeatNo="+row[0].ToString();
						QueryString+= " and pkScheduleNo="+scheduleNo.ToString();
						odbcDataAdapter.DeleteCommand = new OdbcCommand( QueryString, odbcConnection );
						odbcDataAdapter.DeleteCommand.ExecuteNonQuery();

						odbcConnection.Close();

						l.BackColor = System.Drawing.SystemColors.HighlightText;

					}
					catch(Exception ex)
					{
						MessageBox.Show(ex.Message);
					}		


				}
				else
					return;
			}
		}

		private void scheduleInfo_MouseUp(object sender, System.Windows.Forms.MouseEventArgs e)
		{
			this.scheduleInfo.BackColor = System.Drawing.SystemColors.ControlText;
		}

		private void button1_Click(object sender, System.EventArgs e)
		{
			this.price = seatName.Count * 7000;
			this.point = (int )(this.price * 0.1f);
			string str="��      �� : ";
			for(int i=0 ; i<seatName.Count ; i++)
				str += seatName[i].ToString() + ", ";
			
			str += "\r\n";

			str +="��      �� : "+this.price.ToString()+"��\r\n";
			str +="����  ID  : "+textId.Text+"\r\n";
			str +="���ϸ��� : "+point.ToString() + "\r\n\r\n";


			str +="���� �Ͻðڽ��ϱ�??\r\n";

			//OK�� �������� �˻�
			if(MessageBox.Show(str, "�� �� Ȯ ��",
				MessageBoxButtons.OKCancel/*, MessageBoxIcon.Exclamation*/)==DialogResult.OK)
			{
				try
				{				
					DataRow row;      
					DataTable dataTable; 
					DataSet dataSet; 
					string QueryString="";
     
					// �����ͺ��̽� ����
					odbcConnection = new OdbcConnection(source);    
					odbcConnection.Open();

					odbcDataAdapter = new OdbcDataAdapter();
					dataSet = new DataSet();

					//SeatNo ���ϱ�..
					for(int i=0 ; i<this.seatName.Count ; i++)
					{
						QueryString = "SELECT pkSeatNo FROM Seat WHERE SeatName='"+seatName[i].ToString()+"' and pkHallNo="+movieNo.ToString();
						
						odbcDataAdapter.SelectCommand = new OdbcCommand( QueryString, odbcConnection );
						odbcDataAdapter.Fill( dataSet );

						dataTable = dataSet.Tables[0];
						row = dataTable.Rows[i];
						this.seatNo.Add(row[0].ToString());
						//MessageBox.Show(row[0].ToString());						
					}
					//odbcConnection.Close();
					QueryString="";
					
					
					


					// �����ͺ��̽� ����
					//odbcConnection = new OdbcConnection(source);    
					//odbcConnection.Open();
					odbcDataAdapter = new OdbcDataAdapter();

					//�Ǹŵ� Ƽ�� �Է�..
					for(int i=0 ; i<this.seatNo.Count ; i++)
					{
						//MessageBox.Show("a");
						//MessageBox.Show(seatNo[i].ToString()+","+scheduleNo.ToString());
						QueryString = "INSERT INTO Ticket(pkSeatNo, pkScheduleNo) VALUES(";
						QueryString+= seatNo[i].ToString()+", "+scheduleNo.ToString()+")";
						odbcDataAdapter.InsertCommand = new OdbcCommand(QueryString, odbcConnection);
						odbcDataAdapter.InsertCommand.ExecuteNonQuery();
					}
					//odbcConnection.Close();
					QueryString="";					

					//����Ʈ �Է�..		
					//���ϸ����� ������ ID�� �Է��ߴٸ�..
					if((textId.Text.CompareTo("") !=0) || (textId.Text != null))
					{
						// �����ͺ��̽� ����
						//odbcConnection = new OdbcConnection(source);    
						//odbcConnection.Open();
						odbcDataAdapter = new OdbcDataAdapter();

						QueryString = "UPDATE Person SET Point = Point+"+point.ToString();
						odbcDataAdapter.UpdateCommand = new OdbcCommand(QueryString, odbcConnection);
						odbcDataAdapter.UpdateCommand.ExecuteNonQuery();
						
					}
					odbcConnection.Close();

					for(int i=0 ; i<this.row ; i++)
					{
						for(int j=0 ; j<this.col ; j++)
						{
							for(int k=0 ; k<seatName.Count ; k++)
							{
								if(this.seat[i,j].Name.CompareTo(seatName[k].ToString())==0)
								{
									this.seat[i,j].BackColor = System.Drawing.SystemColors.HotTrack;
								}

							}
						}
					}

					//ArrayList ����.
					seatName.Clear();
					seatNo.Clear();
					textId.Text="";
					
				}
				catch(Exception ex)
				{
					MessageBox.Show(ex.Message);
				}				
			}
			else
			{
				
			}
		}	

		//�� �ε��Ҷ� ������ �¼� ��������..
		private void loadData()
		{
			try
			{				
				//DataRow row;      
				DataTable dataTable; 
				DataSet dataSet; 
				string QueryString="";
     
				// �����ͺ��̽� ����
				odbcConnection = new OdbcConnection(source);    
				odbcConnection.Open();

				odbcDataAdapter = new OdbcDataAdapter();
				dataSet = new DataSet();

				//SeatNo ���ϱ�..
				
				QueryString = "SELECT Seat.SeatName FROM Seat, Ticket where Seat.pkSeatNo=Ticket.pkSeatNo";
				QueryString+= " and Ticket.pkScheduleNo="+scheduleNo.ToString();
						
				odbcDataAdapter.SelectCommand = new OdbcCommand( QueryString, odbcConnection );
				odbcDataAdapter.Fill( dataSet );

				dataTable = dataSet.Tables[0];
				
				foreach (DataRow row in dataTable.Rows)
				{					
					seatReve.Add(row[0].ToString());
					
					//MessageBox.Show(row[0].ToString());
				}  									
				
				odbcConnection.Close();

				seatReve.Sort();
				
			}
			catch(Exception ex)
			{
				MessageBox.Show(ex.Message);
			}
		}
		private void loadLabel()
		{
			FileStream file=new FileStream (this.hall+".txt",FileMode.Open);
			StreamReader sr = new StreamReader(file); 			
			//ó���� ����� ���ο��� ���ο��� �о���̰�
			this.row = Int32.Parse(sr.ReadLine()); 
			this.col = Int32.Parse(sr.ReadLine());	
			seatRow = new Label[this.row];
			seatCol = new Label[this.col];
			
			scheduleInfo.Text = schedule;				
			
			char chRow='A';//���ο� ���� �ε���
			int iCol=1;  //���ο� ���� ��ȣ
			char [] s;  //���Ͽ��� �о�ͼ� ��� ��			
			seat = new Label[this.row, this.col];
			string seatName="";


			//����� ���̺� �߰�
			for(int i=0 ; i<this.row ; i++)
			{
				seatRow[i] = new Label();
				this.Controls.Add(this.seatRow[i]);

				for(int j=0 ; j<this.col ; j++)
				{
					seat[i,j] = new Label();
					this.Controls.Add(this.seat[i,j]);

					seatCol[j] = new Label();
					this.Controls.Add(this.seatCol[j]);

				}
			}

			

			//�¼� ��ġ
			for(int i=0 ; i<this.row ; i++)
			{				
				iCol=1;
				s = sr.ReadLine().ToCharArray();			
				

				for(int j=0 ; j<this.col ; j++)
				{					
					
					if(s[j]=='S')
					{
						//this.seat[i,j].Font = new System.Drawing.Font("GulimChe", 7.0F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
								
						if(j<10)
							seatName = chRow+"-"+(iCol)+" ";
						else
							seatName = chRow+"-"+(iCol);
						
						this.seat[i,j].BackColor = System.Drawing.SystemColors.HighlightText;
						this.seat[i,j].Location = new System.Drawing.Point(startX+(j*margin), startY+(i*margin));
						this.seat[i,j].Name = seatName;
						this.seat[i,j].Size = new System.Drawing.Size(size, size);
						this.seat[i,j].TabIndex = 0;
						this.seat[i,j].Text = "";//chRow+"-"+(iCol);
						this.seat[i,j].Click += new System.EventHandler(this.seat_Click);

								
	
						
						//chRow++;	
			
						//index �����ϱ� (��)
						if(j==0)
						{
							//this.Controls.Add(this.seatRow[i]);

							this.seatRow[i].Font = new System.Drawing.Font("GulimChe", 11.0F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
							this.seatRow[i].BackColor = System.Drawing.SystemColors.Control;
							this.seatRow[i].Location = new System.Drawing.Point(startX-20, startY+(i*margin));
							this.seatRow[i].Name = "";
							this.seatRow[i].Size = new System.Drawing.Size(size, size);
							this.seatRow[i].TabIndex = 0;
							this.seatRow[i].Text = chRow.ToString();
							this.scheduleInfo.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			
						}
						//(��)
						if(i==0)
						{					
							this.seatCol[j].Font = new System.Drawing.Font("GulimChe", 8.0F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(129)));
							this.seatCol[j].BackColor = System.Drawing.SystemColors.Control;
							this.seatCol[j].Location = new System.Drawing.Point(startX+(j*margin), startY-20);
							this.seatCol[j].Name = "";
							this.seatCol[j].Size = new System.Drawing.Size(size, size);
							this.seatCol[j].TabIndex = 0;
							this.seatCol[j].Text = iCol.ToString();
							this.scheduleInfo.TextAlign = System.Drawing.ContentAlignment.BottomCenter;
			
						}
						iCol++;
					}
					else
					{
						this.seat[i,j].BackColor = System.Drawing.SystemColors.Control;
						this.seat[i,j].Location = new System.Drawing.Point(startX-(j*margin), startY-(i*margin));
						this.seat[i,j].Name = "";
						this.seat[i,j].Size = new System.Drawing.Size(size, size);
						this.seat[i,j].TabIndex = 0;
						this.seat[i,j].Text = "";
						//this.seat[i,j].Click += new System.EventHandler(this.seat_Click);	
					}
					
					
					this.SuspendLayout();
					
				}
				if(s[1] != ' ')
					chRow++;
			}	
		
			sr.Close();
			file.Close();	
		}
	}
}
